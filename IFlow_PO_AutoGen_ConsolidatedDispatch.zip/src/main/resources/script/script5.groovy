import com.sap.gateway.ip.core.customdev.util.Message;

Message processData(Message message) {
    def bodyText = message.getBody(java.lang.String)  // convert InputStream to String
    message.setProperty("SFData", bodyText)
    return message
}
