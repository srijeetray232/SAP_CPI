import com.sap.gateway.ip.core.customdev.util.Message
import java.io.PrintWriter
import java.io.StringWriter

def Message processData(Message message) {
    // Extract the exception
    def ex = message.getProperty("CamelExceptionCaught")
    
    // Get message body (incoming payload)
    def payload = message.getBody(java.lang.String)

    // Get iFlow details
    def integrationFlowId = message.getProperty("CamelIntegrationFlowId")
    def messageId = message.getProperty("SAP_MessageProcessingId")
    def timestamp = new Date().format("yyyy-MM-dd HH:mm:ss")

    // Convert full stack trace to string
    def sw = new StringWriter()
    def pw = new PrintWriter(sw)
    ex?.printStackTrace(pw)
    def fullStackTrace = sw.toString()

    // Build full error log string
    def errorLog = """
======== SAP CPI ERROR ========
Time: ${timestamp}
iFlow: ${integrationFlowId}
Message ID: ${messageId}

--- Exception Info ---
Type: ${ex?.class?.name}
Message: ${ex?.message}

--- Stack Trace ---
${fullStackTrace}

--- Original Payload ---
${payload}

===============================
"""

    // Store the entire error log in a property (for mail content)
    message.setProperty("CompleteErrorDetails", errorLog)

    // Optional: Add attachment for Message Monitor
    def messageLog = messageLogFactory.getMessageLog(message)
    if(messageLog != null){
        messageLog.addAttachmentAsString("Full_Error_Log", errorLog, "text/plain")
    }

    return message
}
