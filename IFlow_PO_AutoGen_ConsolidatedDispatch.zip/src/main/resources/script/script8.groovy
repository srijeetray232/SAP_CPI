import com.sap.gateway.ip.core.customdev.util.Message
import java.util.HashMap
import groovy.util.XmlSlurper
import javax.activation.DataHandler
import javax.mail.util.ByteArrayDataSource

Message processData(Message message) {
    def body = message.getBody(String)

    // Wrap in root element
    def wrappedXml = "<Root>${body}</Root>"
    def root = new XmlSlurper().parseText(wrappedXml)

    def headers = [
        "Supplier_ID", "Name", "Material", "Quantity", "Price", "DeliveryDays",
        "Email_GoogleSheet", "Email_Salesforce", "Material_SF", 
        "EmailMismatch", "MaterialMismatch"
    ]

    def csv = new StringBuilder()
    csv.append(headers.join(",")).append("\n")

    root.Suppliers.each { supplier ->
        def row = headers.collect { field ->
            def value = supplier."${field}"?.text() ?: ""
            value.replaceAll(",", " ")  // avoid comma breaks
        }
        csv.append(row.join(",")).append("\n")
    }

    // Create DataHandler from CSV content
    def csvBytes = csv.toString().getBytes("UTF-8")
    def dataSource = new ByteArrayDataSource(csvBytes, "text/csv")
    def dataHandler = new DataHandler(dataSource)

    // Attach CSV to message
    def attachmentMap = new HashMap<String, DataHandler>()
    attachmentMap.put("MismatchedSuppliers.csv", dataHandler)
    message.setAttachments(attachmentMap)

    // Optional: plain body text
    message.setBody("Hi Team,\n\nPlease find attached the consolidated CSV file containing supplier records where data mismatches have been identified.\n\nWe kindly request you to carefully review the attached document, assess the discrepancies, and take the necessary corrective actions to resolve these issues.\n\nShould you need any clarification or assistance during the resolution process, please feel free to reach out to the Procurement Team.\n\nYour prompt attention to this matter is highly appreciated.\n\nRegards,\nProcurement Team")

    return message
}