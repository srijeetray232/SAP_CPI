import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.*

Message processData(Message message) {
    def map = message.getProperties()
    def googleJson = new JsonSlurper().parseText(map.get("googleSupplierPayload"))
    def sfJson = new JsonSlurper().parseText(map.get("SFData"))

    def googleRecords = googleJson.values
    def salesforceRecords = sfJson.records

    def mergedList = []

    googleRecords.each { row ->
        def supplierId = row[0]
        def matchingSF = salesforceRecords.find { it.Supplier_ID_c__c == supplierId }

        if (matchingSF) {
            def merged = [
                "Supplier_ID"        : supplierId,
                "Name"               : row[1],
                "Material"           : row[2],
                "Quantity"           : row[3],
                "Price"              : row[4],
                "DeliveryDays"       : row[5],
                "Email_GoogleSheet"  : row[6],
                "Email_Salesforce"   : matchingSF.Email_c__c,
                "Material_SF"        : matchingSF.Material_c__c,
                "EmailMismatch"      : row[6] != matchingSF.Email_c__c,
                "MaterialMismatch"   : row[2] != matchingSF.Material_c__c
            ]
            mergedList << merged
        }
    }

    // ✅ Wrap in an object so CPI can convert it to XML
    def wrappedOutput = [ "Suppliers": mergedList ]
    message.setBody(new JsonBuilder(wrappedOutput).toPrettyString())
    return message
}
