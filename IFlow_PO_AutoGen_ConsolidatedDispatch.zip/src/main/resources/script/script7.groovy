import com.sap.gateway.ip.core.customdev.util.Message
import javax.mail.util.ByteArrayDataSource
import javax.activation.DataHandler
import java.util.UUID

Message processData(Message message) {
    def body = message.getBody(String)

    // Split the input into individual supplier XML blocks
    def suppliers = body.split("(?=<Suppliers>)")

    def poNumber = "PO-" + UUID.randomUUID().toString().take(8).toUpperCase()
    def date = new Date().format("dd-MMM-yyyy")

    def poText = new StringBuilder()
    poText.append("""============================================================
                         PURCHASE ORDER
============================================================
PO Number       : ${poNumber}
Date            : ${date}

Buyer:
Company Name    : Acme Procurement Ltd.
Address         : 123 Industrial Park, Mumbai, India
Email           : procurement@acme.com
Phone           : +91-9876543210

-------------------------------------------------------------------------------------------------------
Line Items:
-------------------------------------------------------------------------------------------------------
| Supplier ID | Supplier Name     | Material      | Qty  | Price (₹) | Delivery Days  | Line Total (₹) |
|-------------|-------------------|---------------|------|-----------|----------------|----------------|
""")

    def total = 0

    suppliers.each { supplierXml ->
        def id = extractTag(supplierXml, "Supplier_ID")
        def name = extractTag(supplierXml, "Name")
        def material = extractTag(supplierXml, "Material")
        def quantity = toSafeInt(extractTag(supplierXml, "Quantity"))
        def price = toSafeInt(extractTag(supplierXml, "Price"))
        def deliveryDays = extractTag(supplierXml, "DeliveryDays")

        if (id && name && material) {
            def lineTotal = quantity * price
            total += lineTotal

            poText.append(String.format("| %-11s | %-17s | %-13s | %-4s | %-9s | %-14s | %-14s |\n",
                id, name, material, quantity, price, deliveryDays, lineTotal))
        }
    }

    poText.append("-------------------------------------------------------------------------------------------------------\n")
    poText.append("Total Order Value: ₹${total}\n\n")
    poText.append("""Terms & Conditions:
1. Delivery must be made within the mentioned delivery period.
2. Invoice must be attached with shipment.
3. Payment within 30 days of delivery.
4. Damaged goods will be returned at supplier's expense.

Authorized Signatory: ______________________
""")

    // Attach PO as a text file
    def ds = new ByteArrayDataSource(poText.toString().getBytes("UTF-8"), "text/plain")
    def handler = new DataHandler(ds)
    def attachments = [:]
    attachments.put("PurchaseOrder.txt", handler)
    message.setAttachments(attachments)

    // Set mail subject & body
    message.setHeader("Subject", "Purchase Order Generated")
    message.setBody("Dear Supplier,\n\nWe hope this message finds you well.\n\nPlease find attached the consolidated Purchase Order pertaining to your recent transactions with us. Kindly review the document in detail and proceed with the necessary actions as per the terms outlined.\n\nIf you have any questions, concerns, or require further clarification, please do not hesitate to reach out to the Procurement Team.\n\nWe appreciate your continued support and cooperation.\n\nRegards,\nProcurement Team")

    return message
}

// Helper to extract XML tag values
String extractTag(String xml, String tag) {
    def matcher = xml =~ "<${tag}>(.*?)</${tag}>"
    return matcher ? matcher[0][1].trim() : ""
}

// Safe conversion from string to int
int toSafeInt(String value) {
    try {
        return Integer.parseInt(value ?: "0")
    } catch (Exception e) {
        return 0
    }
}
