import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;

Message processData(Message message) {
    def body = message.getBody(String)
    def jsonSlurper = new JsonSlurper()
    def suppliers = jsonSlurper.parseText(body)

    def enriched = suppliers.collect { item ->
        def emailMismatch = item.Email_GoogleSheet != item.Email_Salesforce
        def materialMismatch = item.Material != item.Material_SF

        item["EmailMismatch"] = emailMismatch
        item["MaterialMismatch"] = materialMismatch
        return item
    }

    message.setBody(JsonOutput.toJson(enriched))
    return message
}
