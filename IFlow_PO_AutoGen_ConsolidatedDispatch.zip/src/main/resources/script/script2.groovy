import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;

def Message processData(Message message) {
    def body = message.getBody(String)
    def json = new JsonSlurper().parseText(body)

    def supplierList = json.values.collect { row -> row[0] }
    def quoted = supplierList.findAll { it }.collect { "'${it}'" }.join(',')

    def soql = "SELECT Supplier_ID_c__c, Email_c__c, Material_c__c FROM Supplier__c WHERE Supplier_ID_c__c IN (${quoted})"

    // URLEncode the full query to avoid issues with spaces/special characters
    def encodedQuery = java.net.URLEncoder.encode(soql, "UTF-8")

    message.setProperty("salesforceSOQL", encodedQuery)
    return message
}
