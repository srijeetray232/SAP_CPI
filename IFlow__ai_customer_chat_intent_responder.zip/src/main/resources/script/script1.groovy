import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.*

Message processData(Message message) {

    // Read JSON body
    def body = message.getBody(String)
    def json = new JsonSlurper().parseText(body)

    // Extract customer details
    def customerName = json.customer_name ?: "Customer"
    def userMessage = json.message ?: "Hi!"

    // Full prompt (system-style + user-style in 1 message)
    def prompt = """You are a polite customer support agent for an Indian Instagram fashion store.

The customer is ${customerName}. They said: "${userMessage}"

Reply in 2–3 lines. Be friendly, confirm product availability, and respond clearly."""

    // Create OpenAI-style compatible payload
    def payload = [
        model: "google/gemma-3n-e4b-it",
        messages: [
            [role: "user", content: prompt]
        ],
        temperature: 0.7,
        max_tokens: 200
    ]

    // Convert payload to JSON
    def payloadJson = JsonOutput.toJson(payload)
    message.setBody(payloadJson)

    // Set headers
    def headers = message.getHeaders()
    headers.put("Content-Type", "application/json")
    headers.put("Authorization", "Bearer 26186571e9b74702b803db6d665606fd")  // replace with your daily key

    return message
}
