import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.*

Message processData(Message message) {

    def body     = message.getBody(String)
    def json     = new JsonSlurper().parseText(body)
    def replyRaw = json?.choices?.getAt(0)?.message?.content ?: "AI response not available."

    // ✅ Clean reply text
    def replyClean = replyRaw.replaceAll("\\r|\\n", " ").replaceAll("\"", "'").trim()
    message.setProperty("aiResponse", replyClean)

    // ✅ Extract customer name (from property or reply)
    def customerName = message.getProperty("customerName")
    if (!customerName) {
        def nameMatcher = replyClean =~ /(?i)namaste\s+([A-Z][a-z]+)/
        customerName = nameMatcher.find() ? nameMatcher[0][1] : "Unknown"
    }
    message.setProperty("customerName", customerName)

    // ✅ Extract product, quantity, size, paymentMode
    def productName = ""
    def quantity    = ""
    def size        = ""
    def paymentMode = ""

    def sizeMatcher = replyClean =~ /(?i)size[\s:]*([A-Z])/
    if (sizeMatcher.find()) size = sizeMatcher[0][1]

    def qtyProdMatcher = replyClean =~ /(?i)(\d+|one|two|three|four|five|six|seven|eight|nine|ten)\s+(?:[a-zA-Z]+\s*)?(t-shirt|kurti|shirt|jeans|dress|top|combo)/
    if (qtyProdMatcher.find()) {
        quantity    = qtyProdMatcher[0][1]?.isNumber() ? qtyProdMatcher[0][1] : "1"
        productName = qtyProdMatcher[0][2]
    }

    if (!productName) {
        def prodOnly = replyClean =~ /(?i)(t-shirt|kurti|shirt|jeans|dress|top|combo)/
        if (prodOnly.find()) productName = prodOnly[0][1]
    }

    def replyLower = replyClean.toLowerCase()
    if (replyLower.contains("cod") || replyLower.contains("cash on delivery")) {
        paymentMode = "COD"
    } else if (replyLower.contains("upi")) {
        paymentMode = "UPI"
    } else if (replyLower.contains("prepaid")) {
        paymentMode = "Prepaid"
    }

    // ✅ Detect intent
    def intentType = "general_query"
    if (productName && quantity && size) {
        intentType = "order"
    } else if (replyLower.contains("return") || replyLower.contains("refund") || replyLower.contains("exchange")) {
        intentType = "return_query"
    } else if (replyLower.contains("deliver") || replyLower.contains("location") || replyLower.contains("area")) {
        intentType = "delivery_query"
    }

    // ✅ Set properties
    message.setProperty("intentType",  intentType)
    message.setProperty("productName", productName)
    message.setProperty("quantity",    quantity)
    message.setProperty("size",        size)
    message.setProperty("paymentMode", paymentMode)

    return message
}
